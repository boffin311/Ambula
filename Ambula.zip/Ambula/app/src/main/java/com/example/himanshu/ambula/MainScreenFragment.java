package com.example.himanshu.ambula;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import static android.app.Activity.RESULT_OK;

public class MainScreenFragment extends Fragment implements OnMapReadyCallback,GoogleMap.OnCameraMoveListener
        ,GoogleMap.OnCameraMoveStartedListener,GoogleMap.OnCameraMoveCanceledListener,
        GoogleMap.OnCameraIdleListener,View.OnClickListener {
    private GoogleMap mMap;
    TextView tvLocationName;
    FusedLocationProviderClient fusedLocationProviderClient;
    ImageButton imageCurrentLocation;
    GoogleApiClient googleApiClient;
    androidx.appcompat.widget.Toolbar toolbar;
    LocationRequest locationRequest;
    CircleOptions circleOptions;
    MapFragment mapFragment;
    public static final String TAG = "MYCAM";
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private int REQUEST_CODE = 12345;
    private static final int PLACE_SEARCH_REQUEST_CODE = 54321;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        imageCurrentLocation = view.findViewById(R.id.imageCurrentLocation);
        ActivityCompat.requestPermissions(getActivity(), permissions, REQUEST_CODE);

        tvLocationName = view.findViewById(R.id.tvLocationName);
        getGoogleServiceLocation();

//        getPlaceName(28.6967, 77.2058);


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
//        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                .findFragmentById(R.id.map);

        mapFragment = MapFragment.newInstance();
        getActivity().getFragmentManager().beginTransaction().replace(R.id.map, mapFragment)
                .commit();


      mapFragment.getMapAsync(this);

        toolbar = view.findViewById(R.id.toolbar);

        DrawerLayout drawerLayout = view.findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


        /**when currentLocation button is clicked*/
        imageCurrentLocation.setOnClickListener(this);
        tvLocationName.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {


        switch (v.getId()) {
            case R.id.imageCurrentLocation:
                //    Toast.makeText(this, "Inside onCLick", Toast.LENGTH_SHORT).show();

                getGoogleServiceLocation();
                break;
            case R.id.tvLocationName:
                try {
                    Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .build(getActivity());

                    this.startActivityForResult(intent, PLACE_SEARCH_REQUEST_CODE);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }


        }

    }

    @Override
    public void onCameraIdle() {

        tvLocationName.setText(getPlaceName(mMap.getCameraPosition().target.latitude, mMap.getCameraPosition().target.longitude));


    }

    @Override
    public void onCameraMoveCanceled() {

    }

    @Override
    public void onCameraMove() {

    }

    @Override
    public void onCameraMoveStarted(int i) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
//   mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);
//   mMap.get


//        mMap.setOnCameraMoveStartedListener(this);
//        mMap.setOnCameraMoveCanceledListener(this);

        mMap.setOnCameraIdleListener(this);
        mMap.setOnCameraMoveStartedListener(this);


        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(12.9716, 77.5946);
        //  mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney")));

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(sydney, 16));

        mMap.getUiSettings().setAllGesturesEnabled(true);
        Log.d("OMR", "onMapReady: " + mMap.getCameraPosition());
    }


    public void getGoogleServiceLocation() {
        Log.d(TAG, "getGoogleServiceLocation: ");

        googleApiClient = new GoogleApiClient.Builder(getContext())
                .addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks() {
                    @Override
                    public void onConnected(@Nullable Bundle bundle) {
                        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                            return;
                        }
                        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getContext());
                        fusedLocationProviderClient.getLastLocation()
                                .addOnSuccessListener(new OnSuccessListener<Location>() {
                                    @Override
                                    public void onSuccess(Location location) {
                                        if (location != null) {
                                            Log.d(TAG, "onSuccess: " + location.getLongitude());
                                            Log.d(TAG, "onSuccess: " + location.getLatitude());
                                            LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 16));
//                                            mMap.addCircle(new CircleOptions().
//                                                    center(currentLatLng).radius(20).
//                                                    fillColor(R.color.colorPrimary).
//                                                    strokeColor(Color.rgb(255,255,255)).
//                                                    strokeWidth(2));
                                            Log.d(TAG, "onSuccess: " + mMap.getCameraPosition());
                                        }
                                    }
                                });


                    }

                    @Override
                    public void onConnectionSuspended(int i) {

                    }
                })
                .addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        Toast.makeText(getContext(), "Location is not on", Toast.LENGTH_SHORT).show();
                    }
                }).addApi(LocationServices.API)
                .build();
        googleApiClient.connect();

    }

    public String getPlaceName(double latitude, double longitude) {
        Address address = null;
        Geocoder geocoder = new Geocoder(getContext());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            address = addresses.get(0);


        } catch (IOException e) {
            e.printStackTrace();
        }
        return address.getAddressLine(0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            if (requestCode == PLACE_SEARCH_REQUEST_CODE) {
                Place place = PlaceAutocomplete.getPlace(getContext(), data);
                tvLocationName.setText(place.getAddress());

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 16));

            }
        } else {

        }
    }
}
